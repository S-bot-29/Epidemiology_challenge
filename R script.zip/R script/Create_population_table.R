# Load necessary libraries
library(readxl)
library(dplyr)

# Step 1: Specify file path (template for the user to replace)
file_path <- "C:/Users/48669/Desktop/Spatial engineering/Q2/Data Mastery/New data/data_input/voorlopige-bevolkings-gegevens.xlsx" # Replace with your actual file path

# Step 2: Read the Excel file, selecting the "Tabel 1" sheet and skipping unnecessary rows
population <- read_excel(file_path, sheet = "Tabel 1", skip = 9) # Adjust skip if needed

# Step 3: Rename columns appropriately
colnames(population) <- c("Gemeentecode", "Gemeentenaam", "Unused_Column", "Population")

# Step 4: Select only relevant columns
population <- population %>% select(Gemeentecode, Gemeentenaam, Population)

# Step 5: Modify Gemeentecode to add "GE" prefix and retain leading zeros
population <- population %>%
  mutate(Gemeentecode = paste0("GM", sprintf("%04s", Gemeentecode)))

# Step 6: View the first few rows of the cleaned data
head(population)

# Step 7: Save the cleaned data to a CSV file named "population.csv"
output_path <- "C:/Users/48669/Desktop/Spatial engineering/Q2/Data Mastery/New data/data_input/population.csv" # Replace with your desired output file path if needed
write.csv(population, output_path, row.names = FALSE)

