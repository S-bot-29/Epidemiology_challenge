# Load necessary libraries
library(ggplot2)
library(dplyr)
library(scales)

# Specify file path 
setwd("C:/Users/48669/Desktop/Spatial engineering/Q2/Data Mastery/New data")

########################################
# Deceased and wastewater RNA
#######################################
# Load the data
final_data <- read.csv("Final_data_national.csv")

# Convert newDate to Date format
final_data$newDate <- as.Date(final_data$newDate, format="%Y-%m-%d")

# Filter data for the required period
filtered_data <- final_data %>%
  filter(newDate >= as.Date("2021-10-01") & newDate <= as.Date("2022-03-31"))

# Select every two weeks
filtered_data <- filtered_data %>%
  filter(as.numeric(format(newDate, "%W")) %% 2 == 0)

# Create the plot with two y-axes
ggplot(filtered_data, aes(x = newDate)) +
  geom_line(aes(y = deceased_norm, color = "Weekly Deceased"), size = 1) +  # Changed to deceased_norm
  geom_point(aes(y = deceased_norm, color = "Weekly Deceased"), size = 2) +  # Changed to deceased_norm
  geom_line(aes(y = weekly_RNA / max(weekly_RNA, na.rm = TRUE) * max(deceased_norm, na.rm = TRUE), 
                color = "Weekly RNA"), size = 1) +  # Adjusted to normalize with deceased_norm
  geom_point(aes(y = weekly_RNA / max(weekly_RNA, na.rm = TRUE) * max(deceased_norm, na.rm = TRUE), 
                 color = "Weekly RNA"), size = 2) +  # Adjusted to normalize with deceased_norm
  scale_color_manual(values = c("Weekly Deceased" = "red", "Weekly RNA" = "blue")) +
  scale_x_date(date_breaks = "2 weeks", date_labels = "%Y-%m-%d") +
  scale_y_continuous(
    name = "Weekly Deceased (per 100,000 inhabitants)",  # Added "/100,000 inhabitants"
    sec.axis = sec_axis(~ . * max(filtered_data$weekly_RNA, na.rm = TRUE) / 
                          max(filtered_data$deceased_norm, na.rm = TRUE),  # Adjusted to reflect deceased_norm
                        name = "Weekly RNA (per 100,000 inhabitants)")  # Added "/100,000 inhabitants"
  ) +
  labs(
    x = "Date",
    color = "Legend"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 10),  # Adjust x-axis tick label size
    axis.text.y = element_text(size = 10),  # Adjust y-axis tick label size
    axis.title.x = element_text(size = 8),  # Adjust x-axis title size
    axis.title.y = element_text(size = 8),  # Adjust y-axis title size
  )


########################################
# Hospital admissions and wastewater RNA
#######################################

# Create the plot with two y-axes
# Convert newDate to Date format
final_data$newDate <- as.Date(final_data$newDate, format="%Y-%m-%d")

# Filter data for the required period
filtered_data <- final_data %>%
  filter(newDate >= as.Date("2021-10-01") & newDate <= as.Date("2022-03-31"))

# Select every two weeks
filtered_data <- filtered_data %>%
  filter(as.numeric(format(newDate, "%W")) %% 2 == 0)

# Create the plot with two y-axes
ggplot(filtered_data, aes(x = newDate)) +
  geom_line(aes(y = hospital_norm, color = "Weekly Hospital Admissions"), size = 1) +  # Changed to hospital_norm
  geom_point(aes(y = hospital_norm, color = "Weekly Hospital Admissions"), size = 2) +  # Changed to hospital_norm
  geom_line(aes(y = weekly_RNA / max(weekly_RNA, na.rm = TRUE) * max(hospital_norm, na.rm = TRUE), 
                color = "Weekly RNA"), size = 1) +  # Adjusted to normalize with hospital_norm
  geom_point(aes(y = weekly_RNA / max(weekly_RNA, na.rm = TRUE) * max(hospital_norm, na.rm = TRUE), 
                 color = "Weekly RNA"), size = 2) +  # Adjusted to normalize with hospital_norm
  scale_color_manual(values = c("Weekly Hospital Admissions" = "red", "Weekly RNA" = "blue")) +
  scale_x_date(date_breaks = "2 weeks", date_labels = "%Y-%m-%d") +
  scale_y_continuous(
    name = "Weekly Hospital Admissions (per 100,000 inhabitants)",  # Added "/100,000 inhabitants"
    sec.axis = sec_axis(~ . * max(filtered_data$weekly_RNA, na.rm = TRUE) / 
                          max(filtered_data$hospital_norm, na.rm = TRUE),  # Adjusted to reflect hospital_norm
                        name = "Weekly RNA (per 100,000 inhabitants)")  # Added "/100,000 inhabitants"
  ) +
  labs(
    x = "Date",
    color = "Legend"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 10),  # Adjust x-axis tick label size
    axis.text.y = element_text(size = 10),  # Adjust y-axis tick label size
    axis.title.x = element_text(size = 8),  # Adjust x-axis title size
    axis.title.y = element_text(size = 8),  # Adjust y-axis title size
  )


###################################
# Positive cases and wastewater RNA
##################################

# Convert newDate to Date format
final_data$newDate <- as.Date(final_data$newDate, format="%Y-%m-%d")

# Filter data for the required period
filtered_data <- final_data %>%
  filter(newDate >= as.Date("2021-10-01") & newDate <= as.Date("2022-03-31"))

# Select every two weeks
filtered_data <- filtered_data %>%
  filter(as.numeric(format(newDate, "%W")) %% 2 == 0)

# Create the plot with two y-axes
ggplot(filtered_data, aes(x = newDate)) +
  geom_line(aes(y = reported_norm, color = "Weekly Reported Cases"), size = 1) +  # Changed to reported_norm
  geom_point(aes(y = reported_norm, color = "Weekly Reported Cases"), size = 2) +  # Changed to reported_norm
  geom_line(aes(y = weekly_RNA / max(weekly_RNA, na.rm = TRUE) * max(reported_norm, na.rm = TRUE), 
                color = "Weekly RNA"), size = 1) +  # Adjusted to normalize with reported_norm
  geom_point(aes(y = weekly_RNA / max(weekly_RNA, na.rm = TRUE) * max(reported_norm, na.rm = TRUE), 
                 color = "Weekly RNA"), size = 2) +  # Adjusted to normalize with reported_norm
  scale_color_manual(values = c("Weekly Reported Cases" = "red", "Weekly RNA" = "blue")) +
  scale_x_date(date_breaks = "2 weeks", date_labels = "%Y-%m-%d") +
  scale_y_continuous(
    name = "Weekly Reported Cases (per 100,000 inhabitants)",  # Added "/100,000 inhabitants"
    sec.axis = sec_axis(~ . * max(filtered_data$weekly_RNA, na.rm = TRUE) / 
                          max(filtered_data$reported_norm, na.rm = TRUE),  # Adjusted to reflect reported_norm
                        name = "Weekly RNA (per 100,000 inhabitants)")  # Added "/100,000 inhabitants"
  ) +
  labs(
    x = "Date",
    color = "Legend"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 10),  # Adjust x-axis tick label size
    axis.text.y = element_text(size = 10),  # Adjust y-axis tick label size
    axis.title.x = element_text(size = 8),  # Adjust x-axis title size
    axis.title.y = element_text(size = 8),  # Adjust y-axis title size
  )
