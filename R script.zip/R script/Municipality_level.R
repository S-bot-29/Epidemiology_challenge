# Load necessary libraries
library(ggplot2)
library(hrbrthemes)
library(anytime)
library(stringr)
library(fuzzyjoin)
library(lubridate)
library(spatialEco)
library(dplyr)

# Set working directory
setwd("C:/Users/48669/Desktop/Spatial engineering/Q2/Data Mastery/New data") 

# Read datasets
cases <- read.csv("./data_input/COVID-19_cases_per_day.csv", sep = ";")
wastewater <- read.csv("./data_input/COVID-19_rioolwaterdata.csv", sep = ";")
population <- read.csv("./data_input/population.csv") 
wwtp_catchments <- read.csv("./data_input/wwtp_catchments.csv")
cases_general <- read.csv("./data_input/COVID-19_aantallen_gemeente_cumulatief.csv", sep =  ";")

# Inspect first few rows of datasets
head(cases)
head(wastewater)
head(population)
head(wwtp_catchments)
head(cases_general)

# Create a working subset of cases data with unique Municipality_code
cases_subset <- cases %>%
  select(Municipality_code, Security_region_code, Security_region_name) %>%
  distinct(Municipality_code, .keep_all = TRUE)
head(cases_subset)

# Ensure data types are consistent for merging
cases_subset$Municipality_code <- as.character(cases_subset$Municipality_code)
population$Municipality_code <- as.character(population$Gemeentecode)

# Merge cases_subset with population data
muni_pop <- left_join(cases_subset, population, by = c("Municipality_code" = "Gemeentecode"))
head(muni_pop)

# Trim whitespace from Municipality_code columns
cases_subset$Municipality_code <- trimws(cases_subset$Municipality_code)
population$Municipality_code <- trimws(population$Municipality_code)

# Identify Municipality_codes in cases_subset missing from population
discrepancies <- setdiff(cases_subset$Municipality_code, population$Municipality_code)
print(discrepancies)

# Merge general cases data with population data
cases_joined <- left_join(cases_general, muni_pop, by = "Municipality_code")
head(cases_joined)

# Identify missing population values
missing_population <- cases_joined %>%
  filter(is.na(Population)) %>%
  select(Municipality_code) %>%
  distinct()
head(missing_population)

# Remove specific Municipality_codes from dataset
municipality_codes_to_remove <- c("GM0003", "GM0010", "GM0024", "GM0370", "GM0398", "GM0416")
cases_joined_filtered <- cases_joined %>%
  filter(!Municipality_code %in% municipality_codes_to_remove)
head(cases_joined_filtered)

# Remove rows with missing RNA flow values in wastewater data
wastewater <- wastewater[!is.na(wastewater$RNA_flow_per_100000),]
head(wastewater)

# Convert 'Date_measurement' to Date format and extract week number
wastewater$date <- as.Date(wastewater$Date_measurement, format = "%Y-%m-%d")
wastewater$week <- strftime(wastewater$date, format = "%V")

# Aggregate wastewater data based on week
wastewater <- data.frame(wastewater, wastewater$date,
                         newDate = cut(wastewater$date, "week"),
                         stringsAsFactors = FALSE)
head(wastewater)

# Prepare wastewater dataset for merging with WWTP catchments
colna <- colnames(wwtp_catchments)[4:length(colnames(wwtp_catchments))]

hh <- data.frame(unique(wastewater$week))
for (j in colna){
  g <- wwtp_catchments[!is.na(wwtp_catchments[, j]), c("Code_WWTP", j)]
  cc <- merge(x = wastewater[wastewater$RWZI_AWZI_code %in% g$Code_WWTP, ], y = g, by.x = "RWZI_AWZI_code", by.y = "Code_WWTP")
  
  unique_weeks <- unique(cc$week)
  unique_dates <- unique(cc$newDate)
  
  if (length(unique_weeks) < length(unique_dates)) {
    unique_dates <- unique_dates[1:length(unique_weeks)]
  } else if (length(unique_dates) < length(unique_weeks)) {
    unique_weeks <- unique_weeks[1:length(unique_dates)]
  }
  
  kk <- data.frame(unique_weeks, unique_dates)
  colnames(kk) <- c("week", "newDate") 
  
  me <- c()
  for (i in unique(cc$week)) {
    data <- cc[cc$week == i,]
    me <- c(me, sum(data$RNA_flow_per_100000 * (data[, j] / 100)) / length(data$RWZI_AWZI_code))
  }
  kk[, j] <- me
  
  colnames(hh)[1] <- "week"
  hh <- merge(x = hh, y = kk, by = "week", all.x = TRUE)
}

# Rename columns and inspect processed wastewater data
hh <- hh %>% 
  dplyr::rename(date = newDate.x) %>% 
  select(-newDate.y) %>%
  arrange(date)
head(hh)

# Stack data for transformation
stacked_hh <- stack(hh[-1])
Transformedwastewater <- cbind(hh[1:2], stacked_hh)

# Rename columns
Transformedwastewater <- Transformedwastewater %>% 
  dplyr::rename(region_municipality_code = ind, RNA_value = values, weeknumber = week) %>%
  mutate(date = as.Date(date))
head(Transformedwastewater)

# Import municipality names and join with wastewater data
municipality_names <- read.csv("./data_input/municipality_GM_join.csv")
wastewater_areas <- left_join(Transformedwastewater, municipality_names, 
                              by = c("region_municipality_code" = "GM_name"))
head(wastewater_areas)

# Remove missing municipality names from cases data
cases <- cases %>% filter(Municipality_name != "")

# Normalize cases data by population
cases_pop_normalised <- cases_joined_filtered %>%
  mutate(across(c(Total_reported, Hospital_admission, Deceased, Population), as.numeric)) %>%
  filter(!is.na(Total_reported)) %>%
  mutate(
    reported_norm = ((Total_reported / Population) * 100000),
    hospital_norm = ((Hospital_admission / Population) * 100000),
    deceased_norm = ((Deceased / Population) * 100000)
  )

# Convert 'Date_of_publication' to Date format
cases_pop_normalised$Date_of_publication <- as.Date(cases_pop_normalised$Date_of_publication, format = "%Y-%m-%d")

# Aggregate and summarize cases by week
cases_pop_normalised <- cases_pop_normalised %>%
  mutate(PublicationDate = as.Date(cut(Date_of_publication, "week"))) %>%
  group_by(PublicationDate, Municipality_code, Population) %>%
  summarise(across(where(is.numeric), sum, na.rm = TRUE))

# Merge processed cases and wastewater data into final table
FINAL_MUNICIPALITY_TABLE <- merge(wastewater_areas, cases_pop_normalised, by.x =c("date","region_municipality_code"),
                                  by.y=c("PublicationDate","Municipality_code"))
write.csv(FINAL_MUNICIPALITY_TABLE, file = "./data_input/Final_data_municipality.csv", row.names = FALSE)
