# Libraries
library(ggplot2)
library(hrbrthemes)
#library('dplyr')
library(anytime)
library(stringr)
library(fuzzyjoin)
library(lubridate)
library(spatialEco)
library(shiny)
library(dplyr)
library(ggplot2)

# Set working directory
setwd("C:/Users/48669/Desktop/Spatial engineering/Q2/Data Mastery/New data") 

# Read the datasets
cases <- read.csv("./data_input/COVID-19_cases_per_day.csv", sep = ";")
wastewater <- read.csv("./data_input/COVID-19_rioolwaterdata.csv", sep = ";")
population <- read.csv("./data_input/population.csv") # the csv file is created in the script called "create_population_table" 
wwtp_catchments <- read.csv("./data_input/wwtp_catchments.csv")
cases_general <- read.csv("./data_input/COVID-19_aantallen_gemeente_cumulatief.csv", sep =  ";")

# Inspect the first few rows of the datasets to ensure correct loading
head(cases)
head(wastewater)
head(population)
head(wwtp_catchments)
head(cases_general)

# Create a working file (cases_subset) where each Municipality_code occurs only once
cases_subset <- cases %>%
  select(Municipality_code, Security_region_code, Security_region_name) %>%
  distinct(Municipality_code, .keep_all = TRUE)  # Remove duplicates based on Municipality_code
head(cases_subset)
str(cases_subset$Municipality_code)
str(population$Gemeentecode)
cases_subset$Municipality_code <- as.character(cases_subset$Municipality_code)
population$Municipality_code <- as.character(population$Gemeentecode)
muni_pop <- left_join(cases_subset, population, by = c("Municipality_code" = "Gemeentecode"))
head(muni_pop)

# Check for codes in cases_subset that don't exist in population
missing_codes <- setdiff(cases_subset$Municipality_code, population$Municipality_code)
missing_codes
# Convert both to character if they are not the same type
cases_general$Municipality_code <- as.character(cases_general$Municipality_code)

# Perform the left join with cases_general
cases_joined <- left_join(cases_general, muni_pop, by = "Municipality_code")
str(cases_joined)

# View the first few rows to ensure the population column exists
head(cases_joined)

# Check for missing population values
missing_population <- cases_joined %>%
  filter(is.na(Population)) %>%
  select(Municipality_code) %>%
  distinct()

head(missing_population)

# Create a vector of the Municipality_codes you want to delete
municipality_codes_to_remove <- c("GM0003", "GM0010", "GM0024", "GM0370", "GM0398", "GM0416")

# Filter out rows with these Municipality_codes
cases_joined_filtered <- cases_joined %>%
  filter(!Municipality_code %in% municipality_codes_to_remove)

head(cases_joined_filtered)

# Check wastewater data for missing RNA flow values
wastewater <- wastewater[!is.na(wastewater$RNA_flow_per_100000),]
head(wastewater)

# Convert 'Date_measurement' to Date format and extract week number
wastewater$date <- as.Date(wastewater$Date_measurement, format = "%Y-%m-%d")
if (any(is.na(wastewater$date))) {
  print("There are NA values in the date column")
}

# Check the unique weeks and dates
wastewater$week <- strftime(wastewater$date, format = "%V")
print(unique(wastewater$week))
print(unique(wastewater$date))

# Create newDate for analysis (first day of the week)
wastewater <- data.frame(wastewater, wastewater$date,
                         newDate = cut(wastewater$date, "week"),
                         stringsAsFactors = FALSE)

# Clean wastewater data (remove NA values)
wastewater <- wastewater[!is.na(wastewater$RNA_flow_per_100000),]
wastewater$date <- as.Date(wastewater$Date_measurement, format = "%Y-%m-%d")
wastewater$week <- strftime(wastewater$date, format = "%V")

# Set first in the week as the newDate for analysis
wastewater <- data.frame(wastewater, wastewater$date,
                         newDate = cut(wastewater$date, "week"),
                         stringsAsFactors = FALSE)

# Get column names of the WWTP catchments
colna <- colnames(wwtp_catchments)
colna <- colna[4:length(colna)]

# Loop through columns and merge wastewater data
hh <- data.frame(unique(wastewater$week))

for (j in colna){
  g <- wwtp_catchments[!is.na(wwtp_catchments[, j]), c("Code_WWTP", j)]
  cc <- merge(x = wastewater[wastewater$RWZI_AWZI_code %in% g$Code_WWTP, ], y = g, by.x = "RWZI_AWZI_code", by.y = "Code_WWTP")
  
  # Align lengths to match (ensure matching weeks and dates)
  unique_weeks <- unique(cc$week)
  unique_dates <- unique(cc$newDate)
  
  if (length(unique_weeks) < length(unique_dates)) {
    unique_dates <- unique_dates[1:length(unique_weeks)]
  } else if (length(unique_dates) < length(unique_weeks)) {
    unique_weeks <- unique_weeks[1:length(unique_dates)]
  }
  
  # Create the data frame after ensuring lengths match
  kk <- data.frame(unique_weeks, unique_dates)
  colnames(kk) <- c("week", "newDate") 
  
  # Calculate RNA flow per 100,000 for each week
  me <- c()
  for (i in unique(cc$week)) {
    data <- cc[cc$week == i,]
    me <- c(me, sum(data$RNA_flow_per_100000 * (data[, j] / 100)) / length(data$RWZI_AWZI_code))
  }
  kk[, j] <- me
  
  # Ensure correct column names for merging
  colnames(hh)[1] <- "week"
  colnames(kk)[1] <- "week"
  
  hh <- merge(x = hh, y = kk, by = "week", all.x = TRUE)
  hh <- hh[, !duplicated(colnames(hh))]
}

# Inspect column names of 'hh' after the merge
print(colnames(hh))

# Adjust column names
hh <- hh %>% 
  dplyr::rename(date = newDate.x) %>% 
  select(-newDate.y) %>%
  arrange(date)

# Stack 'hh' for transformation
stacked_hh <- stack(hh[-1])
print(colnames(stacked_hh))

# Combine 'hh' and 'stacked_hh'
Transformedwastewater <- cbind(hh[1:2], stacked_hh)

# Inspect combined data frame
print(colnames(Transformedwastewater))
head(Transformedwastewater)

# Rename columns and convert date to Date format
Transformedwastewater <- Transformedwastewater %>% 
  dplyr::rename(region_municipality_code = ind) %>% 
  dplyr::rename(RNA_value = values) %>% 
  dplyr::rename(weeknumber = week) %>%  
  mutate(date = as.Date(date))

# Inspect the final transformed wastewater data
head(Transformedwastewater)

# Import the municipality names and GM codes
municipality_names <- read.csv("./data_input/municipality_GM_join.csv")
head(municipality_names)

# Join wastewater data with municipality names
wastewater_areas <- left_join(Transformedwastewater, municipality_names, 
                              by = c("region_municipality_code" = "GM_name"))
head(wastewater_areas)

# Remove cases with no municipality name
cases <- cases %>% 
  filter(Municipality_name != "")

# Check cumulative reported cases
cases %>% 
  count(Total_reported) %>%  
  mutate(cumsum = cumsum(Total_reported))

# Convert date column to Date format
cases$Date_of_publication <- as.Date(cases$Date_of_publication, format = "%Y-%m-%d")

# Check the result
summary(cases_joined_filtered$Municipality_code)
head(cases_joined_filtered)
str(cases_joined_filtered)

# Generate the population per safety region
pop_region <- muni_pop %>%
  group_by(Security_region_code) %>%
  summarise(sr_population = sum(Population, na.rm = TRUE)) %>%  
  filter(Security_region_code != "")
print(pop_region)

# Join back to include summed population value
cases_pop_region <- left_join (cases_joined_filtered, pop_region, by = "Security_region_code") %>%
  filter(Security_region_code != "")
head(cases_pop_region)

# Investigate if the RWZI name is equal to the municipality names in the wastewater & cases data
wastewater_municipalities <- wastewater %>% 
  select(RWZI_AWZI_name) %>% 
  group_by(RWZI_AWZI_name) %>% 
  distinct()

cases_municipalities <- cases_pop_region %>% 
  group_by(Municipality_name) %>% 
  select(Municipality_name) %>% 
  distinct()

# Identify rows in wastewater data but not in cases
municipality_exist <- anti_join(wastewater_municipalities, 
                                cases_municipalities, 
                                by = c('RWZI_AWZI_name'='Municipality_name'))

# Other epidemiological indicators population normalisation
str(cases_pop_normalised$Date_of_publication)
cases_pop_normalised$Date_of_publication <- as.Date(cases_pop_normalised$Date_of_publication, format = "%Y-%m-%d")

cases_pop_normalised <- cases_pop_region %>%
  filter(!is.na(Total_reported)) %>%
  mutate(reported_norm = ((Total_reported/sr_population)*100000))%>% 
  mutate(hospital_norm = ((Hospital_admission/sr_population)*100000)) %>% 
  mutate(deceased_norm = ((Deceased/sr_population)*100000))
head(cases_pop_normalised)

# Create PublicationDate and aggregate data to week
cases_pop_normalised$Date_of_publication <- as.Date(cases_pop_normalised$Date_of_publication, format = "%Y-%m-%d")
cases_pop_normalised <- data.frame(
  cases_pop_normalised,
  PublicationDate = cut(cases_pop_normalised$Date_of_publication, "week"),
  stringsAsFactors = FALSE
)

# Aggregate data by week
cases_pop_normalised <- cases_pop_normalised %>% 
  mutate(PublicationDate = as.Date(Date_of_publication)) %>% 
  filter(!is.na(sr_population)) %>% 
  group_by(PublicationDate, Security_region_name, Security_region_code, sr_population) %>% 
  summarise_if(is.numeric, sum)
head(cases_pop_normalised)

# Merge wastewater and cases data to create final table
FINAL_REGION_TABLE = merge(wastewater_areas, cases_pop_normalised, by.x = c("date", "region_municipality_code"),
                           by.y = c("PublicationDate", "Security_region_code"))
head(FINAL_REGION_TABLE)

# Save the final table to CSV
write.csv(FINAL_REGION_TABLE, file = "Final_data_region.csv", row.names = FALSE)