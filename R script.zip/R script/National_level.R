# Libraries
library(ggplot2)         
library(dplyr)           
library(anytime)        
library(stringr)         
library(fuzzyjoin)       
library(lubridate)       
library(spatialEco)      
library(shiny)        

# Set working directory
setwd("C:/Users/48669/Desktop/Spatial engineering/Q2/Data Mastery/New data")

# Read datasets
cases <- read.csv("./data_input/COVID-19_cases_per_day.csv", sep = ";")
wastewater <- read.csv("./data_input/COVID-19_rioolwaterdata.csv", sep = ";")
icu <- read.csv("./data_input/COVID-19_icu_admissions.csv", sep = ";")
cases_general <- read.csv("./data_input/COVID-19_aantallen_gemeente_cumulatief.csv", sep =  ";")

# Create a subset of cases with unique Municipality_codes
cases_subset <- cases %>%
  select(Municipality_code, Security_region_code, Security_region_name) %>%
  distinct(Municipality_code, .keep_all = TRUE)

# Convert Municipality_code to character for consistency
cases_general$Municipality_code <- as.character(cases_general$Municipality_code)
cases_subset$Municipality_code <- as.character(cases_subset$Municipality_code)

# Merge the datasets based on Municipality_code
cases_joined <- left_join(cases_general, cases_subset, by = "Municipality_code")

# Clean wastewater data: remove NA values and convert date
wastewater <- wastewater[!is.na(wastewater$RNA_flow_per_100000),]
wastewater$date <- as.Date(wastewater$Date_measurement, format = "%Y-%m-%d")

# Create a weekly summary for wastewater data
wastewater_weekly <- wastewater %>%
  mutate(week = strftime(date, format = "%V"), newDate = cut(date, "week")) %>%
  group_by(newDate, week) %>%
  summarise(weekly_RNA = sum(RNA_flow_per_100000), .groups = "keep")

# Clean and filter cases data
cases <- cases_joined %>%
  filter(Total_reported != "", Hospital_admission != "", Deceased != "") %>%
  filter(Hospital_admission != 9999, Deceased != 9999)

# Convert dates to weekly periods for cases and icu data
cases_new <- cases %>%
  mutate(PublicationDate = cut(Date_of_publication, "week"))

icu_new <- icu %>%
  mutate(PublicationDate = cut(Date_of_statistics, "week"))

# Aggregate data by week and add population info
cases_weekly <- cases_new %>%
  group_by(PublicationDate) %>%
  summarise(weekly_positive_cases = sum(Total_reported), weekly_hospital_admissions = sum(Hospital_admission), weekly_deceased = sum(Deceased)) %>%
  mutate(population = 17590672) 

icu_weekly <- icu_new %>%
  group_by(PublicationDate) %>%
  summarise(weekly_icu_cases = sum(IC_admission)) %>%
  mutate(population = 17590672)

# Normalize data per 100,000 population
cases_pop_normalised <- cases_weekly %>%
  mutate(reported_norm = (weekly_positive_cases/population) * 100000, hospital_norm = (weekly_hospital_admissions/population) * 100000, deceased_norm = (weekly_deceased/population) * 100000)

icu_pop_normalised <- icu_weekly %>%
  mutate(icu_norm = (weekly_icu_cases/population) * 100000)

# Merge wastewater data with the epidemiological data
wastewater_cases_national <- merge(wastewater_weekly, cases_pop_normalised, by.x = "newDate", by.y = "PublicationDate")
wastewater_epi_national <- left_join(wastewater_cases_national, icu_pop_normalised, by = c("newDate" = "PublicationDate"))

# Save the final merged dataset
write.csv(wastewater_epi_national, file = "Final_data_national.csv", row.names = FALSE)

# Filter data for a specific date range and view
wastewater_epi_new <- wastewater_epi_national %>% filter(newDate >= "2021-10-01" & newDate <= "2022-03-31")
View(wastewater_epi_new)
